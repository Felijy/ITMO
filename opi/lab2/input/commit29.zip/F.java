public class F extends null {

    String kk();

    Object rr();
}
