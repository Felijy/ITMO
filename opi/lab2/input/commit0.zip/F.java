public interface F {

    String kk();

    Object rr();
}
