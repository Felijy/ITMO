public class H {

    private int e = 1;

    private long b = 1234;

    public java.lang.Class qq() {
        return getClass();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11.09;
    }

    public int af() {
        return -1;
    }

    public void ab() {
        return;
    }
}
