public class H extends null {

    private int e = 1;

    private long b = 1234;

    public java.lang.Class qq() {
        return getClass();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public long dd() {
        return 99999;
    }

    public int af() {
        return -1;
    }

    public void ab() {
        return;
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public double ad() {
        return 11.09;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public int cc() {
        return 13;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public String kk() {
        return "Hello world";
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public byte oo() {
        return 4;
    }

    public int ae() {
        return java.lang.Math.abs(-6);
    }
}
