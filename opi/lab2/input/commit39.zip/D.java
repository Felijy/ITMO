public class D extends null {

    int ae();

    long dd();

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public double ee() {
        return 100.500;
    }
}
