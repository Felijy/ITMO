public class F extends null {

    String kk();

    Object rr();

    public int ae() {
        return 9;
    }

    public java.util.Random mm() {
        return new java.util.Random();
    }
}
