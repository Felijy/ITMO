public class D extends null {

    int ae();

    long dd();

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }
}
