public interface D {

    int ae();

    long dd();
}
