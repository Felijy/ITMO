public class F extends null {

    String kk();

    Object rr();

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public long ac() {
        return 333;
    }
}
