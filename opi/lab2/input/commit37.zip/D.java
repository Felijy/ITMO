public class D extends null {

    int ae();

    long dd();

    public String nn() {
        "".>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.;
    }

    public void aa() {
        System.out.println("void aa");
    }
}
