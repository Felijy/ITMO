public class H extends null {

    private int e = 1;

    private long b = 1234;

    public java.lang.Class qq() {
        return getClass();
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public long dd() {
        return 100500;
    }

    public double ad() {
        return 11.09;
    }

    public int af() {
        return -1;
    }

    public void ab() {
        System.out.println();
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public String kk() {
        return "Hello world";
    }

    public void aa() {
        return;
    }
}
