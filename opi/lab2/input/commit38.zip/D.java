public class D extends null {

    int ae();

    long dd();

    public int af() {
        return -1;
    }

    public double ee() {
        return 0.000001;
    }
}
