public class A extends null implements D {

    private int b = 1;

    private double h = 100.500;

    public double ad() {
        return 11.09;
    }

    public int cc() {
        return 13;
    }

    public int ae() {
        return 8;
    }

    public long dd() {
        return 33;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public Object pp() {
        return this;
    }

    public float ff() {
        return 3.14;
    }

    public Object rr() {
        return null;
    }

    public java.util.List<String> jj() {
        return new java.util.LinkedList<String>();
    }

    public void ab() {
        System.out.println("\n");
    }

    public long ac() {
        return 111;
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int hh() {
        return new java.util.Random().nextInt();
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public void aa() {
        System.out.println("Hello world!");
    }
}
