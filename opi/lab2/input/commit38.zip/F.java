public class F extends null {

    String kk();

    Object rr();

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public int af() {
        return -1;
    }
}
