public class A implements D {

    private int b = 1;

    private double h = 100.500;

    public double ad() {
        return 11.09;
    }

    public int cc() {
        return 13;
    }

    public int ae() {
        return 8;
    }

    public long dd() {
        return 33;
    }

    public Object pp() {
        return this;
    }
}
